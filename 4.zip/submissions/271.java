import java.util.Scanner;

public class Vectors1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			Scanner reader = new Scanner(System.in);  //Creem un objecte que treballa sobre la consola (System.in)
			
			int suma;
			int pos;
			int n;
			int cont;

            try{
			int casos = reader.nextInt();
			
			for (; casos > 0; casos--){
				suma = 0;
				cont = reader.nextInt();
				
				for (int i = 1; i <= cont; i++) {
					n = reader.nextInt();
					if (i % 3 == 0)
						suma = suma + n;
				}
				System.out.println(suma);
				
			}
            }catch(Exception e){
                
            }
			            
				
	}

}